﻿using System;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class ASP_Project2_Default : System.Web.UI.Page
{
    string strSql = "SELECT [num], [name], [title], [writedate], [readcount], [image],[gopublic],[location],[price]  FROM [requestpost] ORDER BY [num] DESC";

    protected void Page_Load(object sender, EventArgs e)
    {
        search_object.BorderWidth = 0;
        ListDisplay();
    }
    private void ListDisplay()
    {
        requestpost.SelectCommand = strSql;
    }
    protected void Search_Click(object sender, EventArgs e) // 검색기능
    {
        strSql = "SELECT [num], [name], [title], [contents],[writedate], [readcount], [image],[location],[price]  FROM [requestpost] " +
            "where " + search_object.SelectedValue + " Like '%" + SearchBox.Text + "%' ORDER BY [num] desc";

        ListDisplay();
    }

    protected void up_request_Click(object sender, EventArgs e) // 게시글 작성 창 이동
    {
        Response.Redirect("request.aspx");
    }

    //지역 선택 - - - - - - - - - -
    //카테고리별 선택 - 버튼
    // 지역 코드 
    // 1  - 서울
    // 2  - 경기
    // 3  - 인천
    // 4  - 강원
    // 5  - 충북
    // 6  - 충남
    // 7  - 전북
    // 8  - 전남
    // 9  - 경북
    // 10 - 경남
    // 11 - 대구
    // 12 - 부산
    // 13 - 제주
    protected void All(object sender, EventArgs e)
    {
        strSql = "SELECT [num], [name], [title], [contents],[writedate], [readcount], [image], [location], [price] FROM [requestpost] ORDER BY [num] desc";

        ListDisplay();
    }

    protected void Seoul(object sender, EventArgs e)
    {
        strSql = "SELECT [num], [name], [title], [contents],[writedate], [readcount], [image], [location], [price] FROM [requestpost] where loccode= " + 1 + " ORDER BY [num] desc";

        ListDisplay();
    }

    protected void Gyeonggi(object sender, EventArgs e)
    {
        strSql = "SELECT [num], [name], [title], [contents],[writedate], [readcount], [image], [location], [price] FROM [requestpost] where loccode= " + 2 + " ORDER BY [num] desc";

        ListDisplay();
    }

    protected void Incheon(object sender, EventArgs e)
    {
        strSql = "SELECT [num], [name], [title], [contents],[writedate], [readcount], [image], [location], [price] FROM [requestpost] where loccode= " + 3 + " ORDER BY [num] desc";

        ListDisplay();
    }
    protected void Gangwon(object sender, EventArgs e)
    {
        strSql = "SELECT [num], [name], [title], [contents],[writedate], [readcount], [image], [location], [price] FROM [requestpost] where loccode= " + 4 + " ORDER BY [num] desc";

        ListDisplay();
    }
    protected void Chungbug(object sender, EventArgs e)
    {
        strSql = "SELECT [num], [name], [title], [contents],[writedate], [readcount], [image], [location], [price] FROM [requestpost] where loccode= " + 5 + " ORDER BY [num] desc";

        ListDisplay();
    }
    protected void Chungnam(object sender, EventArgs e)
    {
        strSql = "SELECT [num], [name], [title], [contents],[writedate], [readcount], [image], [location], [price] FROM [requestpost] where loccode= " + 6 + " ORDER BY [num] desc";

        ListDisplay();
    }
    protected void Jeonbug(object sender, EventArgs e)
    {
        strSql = "SELECT [num], [name], [title], [contents],[writedate], [readcount], [image], [location], [price] FROM [requestpost] where loccode= " + 7 + " ORDER BY [num] desc";

        ListDisplay();
    }
    protected void Jeonnam(object sender, EventArgs e)
    {
        strSql = "SELECT [num], [name], [title], [contents],[writedate], [readcount], [image], [location], [price] FROM [requestpost] where loccode= " + 8 + " ORDER BY [num] desc";

        ListDisplay();
    }
    protected void Gyeongbug(object sender, EventArgs e)
    {
        strSql = "SELECT [num], [name], [title], [contents],[writedate], [readcount], [image], [location], [price] FROM [requestpost] where loccode= " + 9 + " ORDER BY [num] desc";

        ListDisplay();
    }
    protected void Gyeongnam(object sender, EventArgs e)
    {
        strSql = "SELECT [num], [name], [title], [contents],[writedate], [readcount], [image], [location], [price] FROM [requestpost] where loccode= " + 10 + " ORDER BY [num] desc";

        ListDisplay();
    }
    protected void Daegu(object sender, EventArgs e)
    {
        strSql = "SELECT [num], [name], [title], [contents],[writedate], [readcount], [image], [location], [price] FROM [requestpost] where loccode= " + 11 + " ORDER BY [num] desc";

        ListDisplay();
    }
    protected void Busan(object sender, EventArgs e)
    {
        strSql = "SELECT [num], [name], [title], [contents],[writedate], [readcount], [image], [location], [price] FROM [requestpost] where loccode= " + 12 + " ORDER BY [num] desc";

        ListDisplay();
    }
    protected void Jeju(object sender, EventArgs e)
    {
        strSql = "SELECT [num], [name], [title], [contents],[writedate], [readcount], [image], [location], [price] FROM [requestpost] where loccode= " + 13 + " ORDER BY [num] desc";

        ListDisplay();
    }
}