﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class FinalProject_Default3 : System.Web.UI.Page
{
    protected void LabelID(object sender, EventArgs e)
    {   // Select- 데이터 조회

        SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS;Initial Catalog=2020Project; Integrated Security=False;uid=kim; pwd=qwer1234");

        string sql = "Select id From userinfo Where email = @email";
        SqlCommand cmd = new SqlCommand(sql, con);
        cmd.Parameters.AddWithValue("@email", signinEmail.Text);

        con.Open();
        SqlDataReader rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            //findID.Text = String.Format("{0}", rd["id"]);
            findID.Text = String.Format("회원님의 아이디는 " + "{0}", rd["id"] + " 입니다.<br><br>&nbsp;&nbsp;&nbsp;&nbsp;5초뒤 로그인 페이지로 이동합니다.");
            ment.Text = "회원 ID확인";
            //signup.Text = "GotoLoginPage";
        }
        //signinEmail.Style.Add("visibility", "hidden");
        signinEmail.Style.Add("display", "none");
        signup.Style.Add("display", "none");

        rd.Close();
        con.Close();

        Response.Write("<script language='javascript'>");
        //************************************************************************

        //************************************************************************
        //Response.Write("function movepage(){location.href='loginpage.aspx';}");
        Response.Write("setTimeout('movepage();',5000);");
        Response.Write("</script>");

    }
}