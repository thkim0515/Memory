﻿using System;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ASP_Project2_Default : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Nickname"] != null)
        {
            ListDisplay();
            recommend_label.Text = Session["Nickname"].ToString();
            idcheck.Value = Session["Nickname"].ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('로그인후 이용할 수 있습니다.');location.href=history.back(); </script>");
        }
        String savePath = @"images\";

        if (!IsPostBack)
        {
            SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS;Initial Catalog=2020Project; Integrated Security=False;uid=kim; pwd=qwer1234");

            con.Open();

            string strSql = "Update sellpost SET readcount=readcount + 1 where num=" + Request["No"];
            SqlCommand cmd = new SqlCommand(strSql, con);
            cmd.ExecuteNonQuery();

            strSql = "Select * from sellpost where num = " + Request["No"];

            cmd = new SqlCommand(strSql, con);

            SqlDataReader rd = cmd.ExecuteReader();
            if (rd.Read())
            {
                nickname.Text = rd["name"].ToString();
                writeday.Text = rd["writedate"].ToString();
                readcount.Text = rd["readcount"].ToString();
                title.Text = rd["title"].ToString();
                Contents.Text = rd["contents"].ToString();
                imageout.ImageUrl = savePath + rd["image"].ToString();
            }
            rd.Close();
            con.Close();
        }
    }
    //댓글값이 게시글 번호와 포스트 넘버가 일치하게 맞춘뒤 가져오는구문
    private void ListDisplay()
    {
        SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS;Initial Catalog=2020Project; Integrated Security=False;uid=kim; pwd=qwer1234");

        con.Open();
        string strSql = "Select * from sellpost where num = " + Request["No"];
        SqlCommand cmd = new SqlCommand(strSql, con);
        cmd.ExecuteNonQuery();
        cmd = new SqlCommand(strSql, con);
        SqlDataReader rd = cmd.ExecuteReader();
        rd.Read();
        number_che.Value = rd["num"].ToString();
        rd.Close();

        string strSql2 = "Select * from reply where postnumber = " + Request["No"];
        SqlCommand cmd2 = new SqlCommand(strSql2, con);
        cmd2.ExecuteNonQuery();
        cmd2 = new SqlCommand(strSql2, con);
        SqlDataReader rd2 = cmd2.ExecuteReader();
        rd2.Read();
        string strSql3 = "SELECT [nickname], [comment], [writedate] FROM [reply] where postnumber = " + Request["No"];
        rd2.Close();

        relpy_comment.SelectCommand = strSql3;

        con.Close();
    }

    protected void View_Recom_Btn(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS;Initial Catalog=2020Project; Integrated Security=False;uid=kim; pwd=qwer1234");
        string strSql = Request["No"];
        post_num.Value = strSql;

        string sql = "Insert Into reply (nickname,comment,writedate,postnumber) Values ( @nickname, @comment,@writedate,@postnumber)";

        SqlCommand cmd = new SqlCommand(sql, con);
        cmd.Parameters.AddWithValue("@nickname", recommend_label.Text);
        cmd.Parameters.AddWithValue("@comment", reply.Text);
        cmd.Parameters.AddWithValue("@writedate", DateTime.Now.ToShortDateString());
        cmd.Parameters.AddWithValue("@postnumber", post_num.Value);

        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();

        Response.Write("<script type='text/javascript'>alert('댓글등록 성공'); </script>");  // 댓글등록 성공을 알림
        Response.Redirect(Request.Url.PathAndQuery);                                         // 페이지 새로고침
    }
    protected void back_board_Btn(object sender, EventArgs e)
    {
        Response.Redirect("sellpost.aspx");                                                  // 목록버튼 클릭시
    }

    protected void Delete_Btn_Click(object sender, EventArgs e)
    {
        
        if (Session["super"].ToString() == "관리자")
        {
            Response.Write("<script type='text/javascript'>confirm('게시글을 삭제하시겠습니까?');location.href='sellpost.aspx';</script>");

            SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS;Initial Catalog=2020Project; Integrated Security=False;uid=kim; pwd=qwer1234");

            string Sel_Sel = "select * from sellpost Where num = " + Request["No"];
            string Sel_Rep = "select * from reply Where postnumber = " + Request["No"];
            SqlCommand cmd = new SqlCommand(Sel_Sel, con);
            SqlCommand cmd2 = new SqlCommand(Sel_Rep, con);
            con.Open();

            string Del_Sel = "Delete From sellpost where num = " + Request["No"];
            string Del_Rep = "Delete From reply where postnumber = " + Request["No"];
            //string dbcc_sellpost = "dbcc checkident(sellpost,reseed,0)";
            //string dbcc_reply = "dbcc checkident(reply,reseed,0)";
            SqlCommand sell_Wri = new SqlCommand(Del_Sel, con);
            SqlCommand reply_Wri = new SqlCommand(Del_Rep, con);
            //SqlCommand dbcc_Wri = new SqlCommand(dbcc_sellpost, con);
            //SqlCommand dbcc_Rep = new SqlCommand(dbcc_reply, con);
            sell_Wri.ExecuteNonQuery();
            reply_Wri.ExecuteNonQuery();
            //dbcc_Wri.ExecuteNonQuery();
            //dbcc_Rep.ExecuteNonQuery();
            con.Close();   
        }
        else
        {
            if (idcheck.Value == nickname.Text)
            {

                SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS;Initial Catalog=2020Project; Integrated Security=False;uid=kim; pwd=qwer1234");

                string Sel_Sel = "select * from sellpost Where num = " + Request["No"];
                string Sel_Rep = "select * from reply Where postnumber = " + Request["No"];
                SqlCommand cmd = new SqlCommand(Sel_Sel, con);
                SqlCommand cmd2 = new SqlCommand(Sel_Rep, con);
                con.Open();

                string Del_Sel = "Delete From sellpost where num = " + Request["No"];
                string Del_Rep = "Delete From reply where postnumber = " + Request["No"];
                //string dbcc_sellpost = "dbcc checkident(sellpost,reseed,0)";
                //string dbcc_reply = "dbcc checkident(reply,reseed,0)";
                SqlCommand sell_Wri = new SqlCommand(Del_Sel, con);
                SqlCommand reply_Wri = new SqlCommand(Del_Rep, con);
                //SqlCommand dbcc_Wri = new SqlCommand(dbcc_sellpost, con);
                //SqlCommand dbcc_Rep = new SqlCommand(dbcc_reply, con);
                sell_Wri.ExecuteNonQuery();
                reply_Wri.ExecuteNonQuery();
                //dbcc_Wri.ExecuteNonQuery();
                //dbcc_Rep.ExecuteNonQuery();
                con.Close();

                Response.Write("<script type='text/javascript'>alert('게시물이 삭제되었습니다.');location.href='sellpost.aspx';</script>");

            }
            else
            {
                Response.Write("<script type='text/javascript'>alert('타인이 작성한 게시글을 삭제할 수 없습니다.');window.history.go(-1);</script>");
            }
        }
    }

    protected void Modify_Btn_Click(object sender, EventArgs e)
    {
        //Response.Redirect("~/ASP_Project2/Pass.aspx?Action=Modify&No=" + Request["No"]);
    }
}

// - - - - - - - 댓글기능 테스트

//int count = (int)cmd2.ExecuteScalar();

//if (count > 0)
//{
//    SqlDataReader rd2 = cmd2.ExecuteReader();
//    rd2.Read();
//    if (rd2["postnumber"].ToString() != null)
//    {
//        postnum_che.Value = rd2["postnumber"].ToString();
//    }
//    rd2.Close();
//}

//if (number_che.Value == post_num.Value)
//{
//    string strSql3 = "SELECT [nickname], [comment], [writedate] FROM [reply] where postnumber = " + Request["No"];

//    relpy_comment.SelectCommand = strSql3;
//}
//else
//{

//}